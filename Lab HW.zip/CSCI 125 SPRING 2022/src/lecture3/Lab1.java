package lecture3;

public class Lab1 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x,y; // initializing x and y 
		x=5;
		y=6;
		System.out.println("The value of x is "+x);
		System.out.println("the value of y is " +y );
		System.out.println("---------------");
		x=x+1;
		System.out.println("the value of x is "+x);
		System.out.println("the value of y is "+y);
		
		String sentence = "My first line in java";
		
		String Name = "Obye Shaji ";
		String Email ="oshaji@nyit.edu ";
		String Id = "12345 ";
		
		
		System.out.println(Name+Email+Id);
		

	
	
	
	
	
	}

	
	
	
}
